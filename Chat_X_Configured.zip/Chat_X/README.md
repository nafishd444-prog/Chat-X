# Chat X — lightweight chat app starter

Chat X is a lightweight responsive web app that can also be installed on Android as a PWA. It includes email/password authentication, profile editing, real-time room chat, local music playback, payment *requests* (not real payment processing), and an email-gated admin panel.

## Important reality check
- This project is a web/PWA app, not a signed native APK. It can run in Android Chrome and can be added to the home screen. A true APK can later be made with a trusted Capacitor/Android Studio wrapper.
- Real-time chat and user accounts require your own Firebase project. Do not publish the app with the placeholder Firebase settings.
- Payment UI only records a request. It does not accept money or verify bKash/Nagad transactions. Real payments require an official payment gateway and server-side verification.
- Admin email hiding in JavaScript is not a security boundary by itself. The included database rules are a starter; for production, use server-side admin claims and thoroughly test permissions.
- Do not store private keys, service account JSON, or payment secrets in this frontend.

## 1. Create Firebase project
1. Open https://console.firebase.google.com/ and create a project.
2. In **Authentication → Sign-in method**, enable **Email/Password**.
3. In **Build → Realtime Database**, create a database.
4. In Project settings, add a **Web app** and copy its config.
5. Open `app.js` and replace all `PASTE_...` values in `firebaseConfig`.
6. Set `ADMIN_EMAIL` to the email you will use for the admin account. Create that account in the app first.

## 2. Realtime Database rules
For a learning/demo deployment only, use the rules below in Realtime Database → Rules. They require sign-in and restrict profile updates to the owner, but they are not a complete production security design. Admin payment review is only safe after you replace the email-only admin check with Firebase custom claims and matching rules.

```json
{
  "rules": {
    ".read": false,
    ".write": false,
    "profiles": {
      "$uid": {
        ".read": "auth != null",
        ".write": "auth != null && auth.uid === $uid"
      }
    },
    "rooms": {
      ".read": "auth != null",
      "$room": {
        ".write": "auth != null && (!data.exists() || data.child('createdBy').val() === auth.uid)"
      }
    },
    "messages": {
      "$room": {
        ".read": "auth != null",
        "$message": {
          ".write": "auth != null && !data.exists() && newData.child('uid').val() === auth.uid && newData.child('text').isString() && newData.child('text').val().length <= 1000"
        }
      }
    },
    "public": {
      "notice": {
        ".read": "auth != null",
        ".write": "auth != null && auth.token.email === 'Ahmadullahnafis06@gmail.com'"
      }
    },
    "paymentRequests": {
      ".read": "auth != null && auth.token.email === 'Ahmadullahnafis06@gmail.com'",
      "$uid": {
        ".read": "auth != null && (auth.uid === $uid || auth.token.email === 'Ahmadullahnafis06@gmail.com')",
        ".write": "auth != null && (auth.uid === $uid || auth.token.email === 'Ahmadullahnafis06@gmail.com')"
      }
    }
  }
}
```

Replace `Ahmadullahnafis06@gmail.com` in the rules with your actual admin email. These sample rules are deliberately simple and need review before public use. Payment requests are stored under each user's UID so a user can read only their own requests, while the configured admin email can read the collection. For production, replace email checks with Firebase custom claims and use a trusted backend. If a rule causes `PERMISSION_DENIED`, check Firebase rules and console logs.

## 3. Run it
Because Firebase modules are loaded from the internet, open the site through HTTPS or a local web server; opening `index.html` as a raw `file://` URL may not work.

**Simplest publishing option: GitHub Pages**
1. Create a GitHub repository named `chat-x`.
2. Upload `index.html`, `app.js`, and `manifest.webmanifest`.
3. In repository **Settings → Pages**, choose deploy from your main branch and root folder.
4. Wait for the HTTPS site URL, then open it on your OPPO A18 in Chrome.
5. Chrome menu (⋮) → **Add to Home screen** or **Install app**.

**Local test on a computer:** run `python -m http.server 8000` inside this folder and open `http://localhost:8000`. On Android, use a code editor app with preview/server support or publish to HTTPS.

## 4. Android APK later
To create a native APK, wrap the web app with Capacitor and build it in Android Studio. You need a computer for the normal Android Studio workflow. Do not download random APK-builder tools or share your Firebase/admin credentials with them.

## Included
- `index.html`: responsive interface
- `app.js`: Firebase auth, profiles, real-time messages, local audio player, payment request demo, admin panel
- `manifest.webmanifest`: installable PWA metadata
