// Chat X — Firebase client. Never put service-account/private server keys here.
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged, signOut, updateProfile } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getDatabase, ref, set, get, push, onValue, query, limitToLast, serverTimestamp, update } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-database.js";

// 1) Replace these values with Firebase Console > Project settings > Your apps > Web app config.
const firebaseConfig = {
  apiKey: "AIzaSyCg7_-mnzXCqea-x7RELYPzRLQ0Inu8As0",
  authDomain: "chat-x-57446.firebaseapp.com",
  databaseURL: "https://chat-x-57446-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "chat-x-57446",
  storageBucket: "chat-x-57446.firebasestorage.app",
  messagingSenderId: "1077434831637",
  appId: "1:1077434831637:web:affc9a9e61fa99cd224f1c",
  measurementId: "G-8Q4Y6D6DP1"
};
// 2) Set this to the exact email address you want to use as admin.
const ADMIN_EMAIL = "Ahmadullahnafis06@gmail.com";

const $ = id => document.getElementById(id);
const authView=$("authView"), appView=$("appView");
let app,auth,db,currentUser=null,currentRoom="general",signupMode=false,stopMessages=null,stopNotice=null,stopMyPayments=null,stopAdminPayments=null,stopRooms=null;
const esc = s => String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function setStatus(id,msg){$(id).textContent=msg||""}
function cfgReady(){return firebaseConfig.apiKey && !firebaseConfig.apiKey.startsWith("PASTE_") && firebaseConfig.projectId && !firebaseConfig.projectId.startsWith("PASTE_")}
function initFirebase(){
 if(!cfgReady()){setStatus("authStatus","Setup incomplete: add your Firebase config in app.js first.");return false}
 try{app=initializeApp(firebaseConfig);auth=getAuth(app);db=getDatabase(app);return true}catch(e){setStatus("authStatus","Firebase setup error: "+e.message);return false}
}
$("loginTab").onclick=()=>{signupMode=false;$("nameLabel").classList.add("hidden");$("displayName").classList.add("hidden");$("authSubmit").textContent="Log in";$("loginTab").classList.remove("secondary");$("signupTab").classList.add("secondary");setStatus("authStatus","")};
$("signupTab").onclick=()=>{signupMode=true;$("nameLabel").classList.remove("hidden");$("displayName").classList.remove("hidden");$("authSubmit").textContent="Create account";$("signupTab").classList.remove("secondary");$("loginTab").classList.add("secondary");setStatus("authStatus","")};
$("authForm").addEventListener("submit",async e=>{
 e.preventDefault();if(!auth&&!initFirebase())return;
 const email=$("email").value.trim(),password=$("password").value;
 $("authSubmit").disabled=true;setStatus("authStatus",signupMode?"Creating account…":"Logging in…");
 try{
  if(signupMode){const name=$("displayName").value.trim()||email.split("@")[0];const cred=await createUserWithEmailAndPassword(auth,email,password);await updateProfile(cred.user,{displayName:name});await set(ref(db,"profiles/"+cred.user.uid),{name,email,photoURL:"",createdAt:serverTimestamp()})}
  else await signInWithEmailAndPassword(auth,email,password);
 }catch(err){setStatus("authStatus",friendlyError(err))}finally{$("authSubmit").disabled=false}
});
function friendlyError(e){const map={"auth/email-already-in-use":"This email already has an account.","auth/invalid-email":"Enter a valid email.","auth/weak-password":"Use a password with at least 6 characters.","auth/invalid-credential":"Email or password is incorrect.","auth/network-request-failed":"Network problem. Check your connection.","PERMISSION_DENIED":"Firebase Database rules denied this action. Check README setup."};return map[e.code]||e.message||"Something went wrong."}
$("signOutBtn").onclick=()=>signOut(auth);
onAuthStateChangedSafe();
function onAuthStateChangedSafe(){if(!cfgReady())return;if(!auth)initFirebase();if(auth)onAuthStateChanged(auth,user=>{currentUser=user;if(user){authView.classList.add("hidden");appView.classList.remove("hidden");$("signOutBtn").classList.remove("hidden");loadUser();loadRooms();listenNotice();listenMyPayments();if(user.email?.toLowerCase()===ADMIN_EMAIL.toLowerCase()){ $("adminTab").classList.remove("hidden");listenAdminPayments();loadAdminStats()}else $("adminTab").classList.add("hidden");selectPanel("chatPanel");listenMessages()}else{authView.classList.remove("hidden");appView.classList.add("hidden");$("signOutBtn").classList.add("hidden");cleanup()}})}
function cleanup(){[stopMessages,stopNotice,stopMyPayments,stopAdminPayments,stopRooms].forEach(f=>{if(typeof f==="function")f()});stopMessages=stopNotice=stopMyPayments=stopAdminPayments=stopRooms=null}
async function loadUser(){
 $("myName").textContent=currentUser.displayName||currentUser.email.split("@")[0];$("myEmail").textContent=currentUser.email||"";
 try{const snap=await get(ref(db,"profiles/"+currentUser.uid));const p=snap.val()||{};$("profileName").value=p.name||currentUser.displayName||"";$("photoURL").value=p.photoURL||"";paintAvatar(p.photoURL,p.name||currentUser.displayName||"U")}catch{}
}
function paintAvatar(url,name){$("myAvatar").innerHTML=url?`<img alt="" src="${esc(url)}">`:esc((name||"U").slice(0,1).toUpperCase())}
$("saveProfileBtn").onclick=async()=>{const name=$("profileName").value.trim().slice(0,32),photoURL=$("photoURL").value.trim();if(!name){setStatus("profileStatus","Enter a display name.");return}try{await updateProfile(currentUser,{displayName:name,photoURL});await update(ref(db,"profiles/"+currentUser.uid),{name,photoURL,email:currentUser.email});await loadUser();setStatus("profileStatus","Profile saved.")}catch(e){setStatus("profileStatus",friendlyError(e))}}
function selectPanel(id){for(const p of ["chatPanel","profilePanel","musicPanel","paymentPanel","adminPanel"])$(p).classList.toggle("hidden",p!==id);document.querySelectorAll("[data-panel]").forEach(b=>b.classList.toggle("secondary",b.dataset.panel!==id))}
document.querySelectorAll("[data-panel]").forEach(b=>b.addEventListener("click",()=>{if(b.dataset.panel==="adminPanel"&&currentUser?.email?.toLowerCase()!==ADMIN_EMAIL.toLowerCase())return;selectPanel(b.dataset.panel)}));
document.querySelectorAll("[data-room]").forEach(b=>b.addEventListener("click",()=>setRoom(b.dataset.room)));
function setRoom(room){currentRoom=room;$("roomTitle").textContent="# "+room;$("messages").innerHTML="";document.querySelectorAll("[data-room]").forEach(b=>b.classList.toggle("active",b.dataset.room===room));listenMessages()}
$("createRoomBtn").onclick=async()=>{const room=$("newRoom").value.trim().toLowerCase().replace(/[^a-z0-9_-]/g,"").slice(0,24);if(!room){return}try{await set(ref(db,"rooms/"+room),{createdBy:currentUser.uid,createdAt:serverTimestamp()});$("newRoom").value="";await loadRooms();setRoom(room)}catch(e){setStatus("chatStatus",friendlyError(e))}}
async function loadRooms(){if(stopRooms)stopRooms();stopRooms=onValue(ref(db,"rooms"),snap=>{const data=snap.val()||{};const defaults={general:{},friends:{}};const all={...defaults,...data};$("roomList").innerHTML=Object.keys(all).sort().map(r=>`<button class="room ${r===currentRoom?"active":""}" data-room="${esc(r)}"><div class="avatar">${r==="general"?"#":"♡"}</div><div class="grow"><b>${esc(r)}</b><small>Open room</small></div></button>`).join("");document.querySelectorAll("[data-room]").forEach(b=>b.addEventListener("click",()=>setRoom(b.dataset.room)))},()=>setStatus("chatStatus","Could not load rooms. Check database rules."))}
function listenMessages(){if(stopMessages)stopMessages();if(!db||!currentUser)return;const q=query(ref(db,"messages/"+currentRoom),limitToLast(100));stopMessages=onValue(q,snap=>{const vals=Object.entries(snap.val()||{}).map(([id,m])=>({id,...m}));$("messages").innerHTML=vals.map(m=>{const mine=m.uid===currentUser.uid;const time=m.createdAt?new Date(m.createdAt).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}):"sending";return `<div class="msg ${mine?"mine":""}"><div class="bubble">${mine?"":`<b>${esc(m.name||"User")}</b><br>`}${esc(m.text)}</div><div class="meta">${time}${mine?" · you":""}</div></div>`}).join("")||'<div class="muted tiny">No messages yet. Start the conversation.</div>';$("messages").scrollTop=$("messages").scrollHeight;setStatus("chatStatus","")},()=>setStatus("chatStatus","Message access denied. Check README rules."))}
$("messageForm").addEventListener("submit",async e=>{e.preventDefault();const text=$("messageInput").value.trim();if(!text)return;$("sendBtn").disabled=true;try{await push(ref(db,"messages/"+currentRoom),{uid:currentUser.uid,name:currentUser.displayName||currentUser.email.split("@")[0],text,createdAt:serverTimestamp()});$("messageInput").value=""}catch(err){setStatus("chatStatus",friendlyError(err))}finally{$("sendBtn").disabled=false}});
function listenNotice(){if(stopNotice)stopNotice();stopNotice=onValue(ref(db,"public/notice"),s=>{$("noticeText").textContent=s.val()?.text||"Chat with your community"})}
$("paymentRequestBtn").onclick=async()=>{const amount=Number($("payAmount").value),method=$("payMethod").value,note=$("payNote").value.trim();if(!Number.isFinite(amount)||amount<=0){setStatus("paymentStatus","Enter a valid amount.");return}try{await push(ref(db,"paymentRequests/"+currentUser.uid),{uid:currentUser.uid,email:currentUser.email,amount,method,note,status:"pending",createdAt:serverTimestamp()});$("payAmount").value="";$("payNote").value="";setStatus("paymentStatus","Request submitted. This is not a payment confirmation.");}catch(e){setStatus("paymentStatus",friendlyError(e))}}
function listenMyPayments(){if(stopMyPayments)stopMyPayments();stopMyPayments=onValue(ref(db,"paymentRequests/"+currentUser.uid),s=>{const items=Object.entries(s.val()||{}).reverse();$("myPayments").innerHTML=items.length?items.map(([id,p])=>`<div class="stat" style="margin:7px 0"><b>৳${esc(p.amount)}</b><span>${esc(p.method)} · ${esc(p.status||"pending")}</span><div class="tiny muted">${p.createdAt?new Date(p.createdAt).toLocaleString():"Just now"}</div></div>`).join(""):"No requests yet."})}
function isAdmin(){return currentUser?.email?.toLowerCase()===ADMIN_EMAIL.toLowerCase()}
function listenAdminPayments(){if(!isAdmin())return;if(stopAdminPayments)stopAdminPayments();stopAdminPayments=onValue(ref(db,"paymentRequests"),s=>{const items=Object.entries(s.val()||{}).flatMap(([uid,requests])=>Object.entries(requests||{}).map(([id,p])=>({id,uid,p}))).reverse();$("adminPayments").innerHTML=items.length?items.map(({id,uid,p})=>`<div class="stat" style="margin:7px 0"><b>৳${esc(p.amount)} · ${esc(p.method)}</b><div>${esc(p.email||uid)} · ${esc(p.status||"pending")}</div><div class="tiny muted">${esc(p.note||"No note")}</div><div class="row" style="margin-top:8px"><button class="secondary" data-pay="${esc(uid+"/"+id)}" data-status="approved">Mark reviewed</button><button class="danger" data-pay="${esc(uid+"/"+id)}" data-status="rejected">Reject</button></div></div>`).join(""):"No payment requests.";document.querySelectorAll("[data-pay]").forEach(b=>b.onclick=async()=>{if(!isAdmin())return;try{await update(ref(db,"paymentRequests/"+b.dataset.pay),{status:b.dataset.status,reviewedBy:currentUser.uid,reviewedAt:serverTimestamp()});setStatus("adminStatus","Request updated.")}catch(e){setStatus("adminStatus",friendlyError(e))}});$("paymentCount").textContent=items.length},()=>setStatus("adminStatus","Cannot read payment requests."))}
async function loadAdminStats(){if(!isAdmin())return;try{const [u,m]=await Promise.all([get(ref(db,"profiles")),get(ref(db,"messages"))]);$("userCount").textContent=Object.keys(u.val()||{}).length;$("messageCount").textContent=Object.values(m.val()||{}).reduce((n,r)=>n+Object.keys(r||{}).length,0)}catch{}}
$("saveNoticeBtn").onclick=async()=>{if(!isAdmin())return;const text=$("adminNotice").value.trim().slice(0,300);try{await set(ref(db,"public/notice"),{text,updatedAt:serverTimestamp(),updatedBy:currentUser.uid});setStatus("adminStatus","Notice published.")}catch(e){setStatus("adminStatus",friendlyError(e))}}
// Local-only music; the selected file is never uploaded.
let audioUrl=null;
$("musicFile").addEventListener("change",()=>{const f=$("musicFile").files?.[0];if(!f)return;if(audioUrl)URL.revokeObjectURL(audioUrl);audioUrl=URL.createObjectURL(f);$("audio").src=audioUrl;$("musicTitle").textContent=f.name});
$("playBtn").onclick=()=>{const a=$("audio");if(!a.src){$("musicTitle").textContent="Choose an audio file first.";return}if(a.paused)a.play().catch(()=>{});else a.pause()};
$("stopBtn").onclick=()=>{const a=$("audio");a.pause();a.currentTime=0};
